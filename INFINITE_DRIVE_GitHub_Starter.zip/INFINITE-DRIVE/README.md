# INFINITE DRIVE — GitHub Web Prototype

This is a browser-playable 3D driving prototype using Three.js.

## Run locally
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Use the VS Code Live Server extension, or run a local static server.
4. Open `index.html` through the local server (ES modules usually do not work reliably from file://).

## Publish on GitHub Pages
1. Create a public repository named `INFINITE-DRIVE`.
2. Upload `index.html` to the repository root.
3. Commit the file.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select `main` and `/ (root)`, then Save.
7. Wait for the Pages URL to appear.

## Controls
- PC: W / Up = accelerate, S / Down / Space = brake, A / Left = steer left, D / Right = steer right.
- Touch: use on-screen steering, brake and gas buttons.

## Important scope
This is a playable starter prototype, not the complete final game. It uses primitive placeholder geometry rather than licensed car/road assets. It does not yet implement real suspension/wheel physics, a full procedural multi-biome road generator, rain particle simulation, audio radio stations, saved garage customization, native APK/EXE packaging, or online multiplayer. Those features require additional implementation and testing. GitHub Pages hosts the web build only; use GDevelop or a packaging workflow for native Android/Windows exports.
